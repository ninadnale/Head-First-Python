from setuptools import setup

setup(
	name = 'DBcm',
	version = '1.0',
	description = 'The Head First Python Database tools',
	author = 'ninadnale',
	author_email = 'ninadnale@gmail.com',
	url = 'headfirstlabs.com',
	py_modules = ['DBcm'],
	)
